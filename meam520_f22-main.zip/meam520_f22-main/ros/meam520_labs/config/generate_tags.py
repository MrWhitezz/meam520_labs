start_id = 300
end_id = 320

for i in range(start_id, end_id+1):
    print("{id: %s, size: 0.04}, "%i)